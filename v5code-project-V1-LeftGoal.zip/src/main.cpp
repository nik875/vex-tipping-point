/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author                                                                  */
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
 
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LB                   motor         1               
// RB                   motor         2               
// LF                   motor         3               
// RF                   motor         4               
// Conveyor             motor         6               
// Clamp                motor         5               
// Tilter               motor         8               
// FourBar              motor         9               
// Controller1          controller                    
// Controller2          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----
 
#include "vex.h"
#include <math.h>
 
using namespace vex;
 
// A global instance of competition
competition Competition;
 
// define your global instances of motors and other devices here
double ROBOTCIRCUMFRENCE = 58.12;
double DEGREESPERINCH = 360 / 12.56;
int team = 0;
static double xPos = 1;
static double yPos = 11;
static double dir = 0;
void pre_auton(void)
{
 // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  LB.setStopping(brake);
  RB.setStopping(brake);
  LF.setStopping(brake);
  RF.setStopping(brake);
}

double abs2(double val) {
  if (val > 0) return val;
  else return -1 * val;
}

void stopAllMotors() {
  LB.stop();
  LF.stop();
  RB.stop();
  RF.stop();
}

void turnTo(double targAngle, int turnDir = 0) {
  /*
  Turn to targAngle
  turnDir = 0 for shortest, turnDir = 1 for left turn, turnDir = 2 for right turn
  */
  if (turnDir == 0) {
    if (abs2(targAngle - dir) < 180) turnDir = 1;
    else turnDir = 2;
  }
  if (turnDir == 1) {
    double val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (targAngle - dir);
    if (targAngle < dir) val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (360 - (targAngle - dir));
    RF.startRotateFor(forward, val, degrees);
    RB.startRotateFor(forward, val, degrees);
    LF.startRotateFor(reverse, val, degrees);
    LB.spinFor(reverse, val, degrees);
  }
  else if (turnDir == 2) {
    double val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (targAngle - dir);
    if (targAngle > dir) val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (360 - (targAngle - dir));
    RF.startRotateFor(reverse, val, degrees);
    RB.startRotateFor(reverse, val, degrees);
    LF.startRotateFor(forward, val, degrees);
    LB.spinFor(forward, val, degrees);
  }
  stopAllMotors();
  dir = targAngle;
}

void move(double dist) {
  /*
  Move forward "dist" feet
  */
  LB.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  RB.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  LF.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  RF.spinFor(forward, dist * DEGREESPERINCH * 12, degrees);
  stopAllMotors();
}

void goTo(double targX, double targY, bool forward = true) {
  double targAngle = tan((targX - xPos) / (targY - yPos));
  if (!forward) {
    if (targAngle > 180)
      targAngle = targAngle + 180 - 360;
    else
      targAngle = targAngle + 180;
  }
  turnTo(targAngle);
  double dist = pow(pow(targX - xPos, 2) + pow(targY - yPos, 2), .5);
  if (forward) move(dist);
  else move(-1 * dist);
  xPos = targX;
  yPos = targY;
}

void pickUpTower() {
  //Implement
}

void cycleConveyor() {
  Conveyor.spin(forward);
}

//red bottom autonomous/Blue Top
void autonomous(void) {
  goTo(1, 9.5, false );
  wait(0.5, seconds);
  pickUpTower();
  cycleConveyor();
}
 
void usercontrol(void)
{
 bool yPressed = false;
 bool autoEject = false;

 while (true)
 {
   //Drive
   if ((Controller1.Axis3.value() < -2 && Controller1.Axis2.value() < -2) || (Controller1.Axis3.value() > 2 && Controller1.Axis2.value() > 2))
   {
     if (abs(Controller1.Axis3.value() - Controller1.Axis2.value()) < 10)
     {  
       LB.spin(fwd, Controller1.Axis3.value() * 1 / 2, velocityUnits::pct);
       RB.spin(fwd, Controller1.Axis2.value() * 1 / 2, velocityUnits::pct);
       LF.spin(fwd, Controller1.Axis3.value() * 1 / 2, velocityUnits::pct);
       RF.spin(fwd, Controller1.Axis2.value() * 1 / 2, velocityUnits::pct);
     }
    
    else
    {
      LB.spin(fwd, Controller1.Axis3.value() * 1 / 2, pct);
      RB.spin(fwd, Controller1.Axis2.value() * 1 / 2, pct);
      LF.spin(fwd, Controller1.Axis3.value() * 1 / 2, pct);
      RF.spin(fwd, Controller1.Axis2.value() * 1 / 2, pct);
    }
   }
   //Titler - L2
   bool up = false;

   if(Controller2.ButtonL2.pressing() && up == false) {

    Tilter.spinFor(forward, 5, degrees);

   } else if(Controller2.ButtonL2.pressing() && up == true) {

    Tilter.spinFor(reverse, 5, degrees);
   }
    //Claw - R2
    bool holding = false;
   if(Controller2.ButtonR2.pressing() && holding == false){

     Clamp.spinFor(forward, 5, degrees);
     holding = true;

   } else if(Controller2.ButtonR2.pressing() && holding == true){

     Clamp.spinFor(reverse, 5, degrees);
     holding = false;
   } 
    //Conveyer - A
     bool running = false;
   if(Controller2.ButtonR2.pressing() && running == false){

     Conveyor.spinFor(forward, 5, degrees);
     running = true;

   } else if(Controller2.ButtonR2.pressing() && running == true){

     Conveyor.spinFor(reverse, 5, degrees);
     running = false;
   } 

    //FourBar - Axis 2 (Right Joystick) 
    if(Controller2.Axis2.value() != 0){

     FourBar.spin(fwd, Controller2.Axis2.value() *0.5 , velocityUnits::pct);

    }
   

   
  }
 }

int main(){

 // Set up callbacks for autonomous and driver control periods.
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);
 // Run the pre-autonomous function.
 pre_auton();
 // Prevent main from exiting with an infinite loop.
}


/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
 
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LB                   motor         20             
// RB                   motor         10             
// LF                   motor         11             
// RF                   motor         1              
// LIn                  motor         12             
// RIn                  motor         2              
// Controller1          controller                   
// Controller2          controller                   
// ConveyerMotor        motor         8              
// Strafe               motor         3              
// Vision1              vision        4              
// Optical              optical       7              
// Distance             distance      17             
