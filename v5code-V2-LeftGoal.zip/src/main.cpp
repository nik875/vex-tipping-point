/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author                                                                  */
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
 
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LB                   motor         3               
// RB                   motor         1               
// LF                   motor         12              
// RF                   motor         11              
// Conveyor             motor         4               
// Clamp                motor         20              
// Tilter               motor         10              
// FourBar              motor         21              
// Controller1          controller                    
// Controller2          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----
 
#include "vex.h"
#include <math.h>
 
using namespace vex;
 
// A global instance of competition
competition Competition;
 
// define your global instances of motors and other devices here
double ROBOTCIRCUMFRENCE = 58.12;
double DEGREESPERINCH = 360 / 12.56;
int team = 0;
static double xPos = 1;
static double yPos = 11;
static double dir = 0;
void pre_auton(void)
{
 // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  LB.setStopping(brake);
  RB.setStopping(brake);
  LF.setStopping(brake);
  RF.setStopping(brake);
}

double abs2(double val) {
  if (val > 0) return val;
  else return -1 * val;
}

void stopAllMotors() {
  LB.stop();
  LF.stop();
  RB.stop();
  RF.stop();
}

void turnTo(double targAngle, int turnDir = 0) {
  /*
  Turn to targAngle
  turnDir = 0 for shortest, turnDir = 1 for left turn, turnDir = 2 for right turn
  */
  if (turnDir == 0) {
    if (abs2(targAngle - dir) < 180) turnDir = 1;
    else turnDir = 2;
  }
  if (turnDir == 1) {
    double val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (targAngle - dir);
    if (targAngle < dir) val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (360 - (targAngle - dir));
    RF.startRotateFor(forward, val, degrees);
    RB.startRotateFor(forward, val, degrees);
    LF.startRotateFor(reverse, val, degrees);
    LB.spinFor(reverse, val, degrees);
  }
  else if (turnDir == 2) {
    double val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (targAngle - dir);
    if (targAngle > dir) val = (DEGREESPERINCH * ROBOTCIRCUMFRENCE / 360) * (360 - (targAngle - dir));
    RF.startRotateFor(reverse, val, degrees);
    RB.startRotateFor(reverse, val, degrees);
    LF.startRotateFor(forward, val, degrees);
    LB.spinFor(forward, val, degrees);
  }
  stopAllMotors();
  dir = targAngle;
}

void move(double dist) {
  /*
  Move forward "dist" feet
  */
  LB.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  RB.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  LF.startRotateFor(forward, dist * DEGREESPERINCH * 12, degrees);
  RF.spinFor(forward, dist * DEGREESPERINCH * 12, degrees);
  stopAllMotors();
}

void goTo(double targX, double targY, bool forward = true) {
  double targAngle = tan((targX - xPos) / (targY - yPos));
  if (!forward) {
    if (targAngle > 180)
      targAngle = targAngle + 180 - 360;
    else
      targAngle = targAngle + 180;
  }
  turnTo(targAngle);
  double dist = pow(pow(targX - xPos, 2) + pow(targY - yPos, 2), .5);
  if (forward) move(dist);
  else move(-1 * dist);
  xPos = targX;
  yPos = targY;
}

void pickUpTower() {
  //Implement
}

void cycleConveyor() {
  Conveyor.spin(forward);
}

//red bottom autonomous/Blue Top
void autonomous(void) {
  goTo(1, 9.5, false );
  wait(0.5, seconds);
  pickUpTower();
  cycleConveyor();
}
 
void usercontrol(void)
{
  LB.setStopping(coast);
  RB.setStopping(coast);
  LF.setStopping(coast);
  RF.setStopping(coast);
  FourBar.setStopping(brake);
 while (true)
 {
   int x = 0;
   
    if ((Controller1.Axis3.value() < -2 && Controller1.Axis2.value() < -2) || (Controller1.Axis3.value() > 2 && Controller1.Axis2.value() > 2))
    {
      if (abs(Controller1.Axis3.value() - Controller1.Axis2.value()) < 10)
      {   
        LB.spin(fwd, -Controller1.Axis3.value() * 1, velocityUnits::pct);
        RB.spin(fwd, Controller1.Axis2.value() * 1, velocityUnits::pct);
        LF.spin(fwd, -Controller1.Axis3.value() *1, velocityUnits::pct);
        RF.spin(fwd, Controller1.Axis2.value() *1, velocityUnits::pct);
      }
      else
      {
        LB.spin(fwd, -Controller1.Axis3.value(), pct);
        RB.spin(fwd, Controller1.Axis2.value(), pct);
        LF.spin(fwd, -Controller1.Axis3.value(), pct);
        RF.spin(fwd, Controller1.Axis2.value(), pct);
      }
    }
    else
    {
      LB.spin(fwd, -Controller1.Axis3.value(),pct);
      RB.spin(fwd, Controller1.Axis2.value(), pct);
      LF.spin(fwd, -Controller1.Axis3.value(), pct);
      RF.spin(fwd, Controller1.Axis2.value(), pct);
    }
   //Titler - L2
  
   if(Controller2.ButtonL2.pressing() && x == 0) {

    Tilter.startRotateFor(reverse, 327.65, degrees);
    x++;
   } else if(Controller2.ButtonL1.pressing() && x == 1) {

    Tilter.startRotateFor(forward, 327.65, degrees);
    x--;
   }
    //Clamp - R2 & R1
  if(Controller2.ButtonR2.pressing())
   {
     Clamp.spin(fwd,-50, velocityUnits::pct); 

   }
   else if (Controller2.ButtonR1.pressing())
    {

      Clamp.rotateFor(fwd, 165, degrees);
    }
   
    //Conveyer - A
   if(Controller2.ButtonA.pressing()){

     Conveyor.spin(fwd, 50 ,velocityUnits::pct);

   } else if(Controller2.ButtonX.pressing()){

     Conveyor.spin(reverse, 0 ,velocityUnits::pct);
   } 

    //FourBar - Axis 2 (Right Joystick) 
    if(Controller2.Axis2.value() > 2 || Controller2.Axis2.value() < -2) {
      FourBar.spin(forward, -Controller2.Axis2.value(), velocityUnits::pct);
    }
     else 
    {
      FourBar.spin(forward, 0, velocityUnits::pct);

    }
   

   
  }
 }

int main(){

 // Set up callbacks for autonomous and driver control periods.
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);
 // Run the pre-autonomous function.
 pre_auton();
 // Prevent main from exiting with an infinite loop.
}


/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
 
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LB                   motor         20             
// RB                   motor         10             
// LF                   motor         11             
// RF                   motor         1              
// LIn                  motor         12             
// RIn                  motor         2              
// Controller1          controller                   
// Controller2          controller                   
// ConveyerMotor        motor         8              
// Strafe               motor         3              
// Vision1              vision        4              
// Optical              optical       7              
// Distance             distance      17             